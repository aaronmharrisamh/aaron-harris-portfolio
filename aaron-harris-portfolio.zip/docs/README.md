# Built-in copy editor (hidden)

`index.html` ships with a hidden, self-contained copy editor for fixing typos,
tuning copy, and managing gallery images directly on the live page, then
downloading the updated monofile. Casual visitors can never see it. This doc is
local-only (`docs/` is gitignored).

## Quick start

1. Open the live page (must be served over HTTP: GitHub Pages or a local server;
   `file://` cannot export).
2. Open the F12 console and run `edit()`.
3. Badge bubbles ({A01}, {A02}, ...) appear at the start of every editable region,
   plus a panel in the bottom-right listing all regions.
4. Click a badge (or a panel row) to open the editor modal. Edit the raw innerHTML,
   press **Apply** to see it live.
5. When done, run `edit.export()` (or press **Export** in the panel). A new
   `index.html` downloads with your edits spliced in. Replace the repo file with it,
   review the diff, commit, push.

## Console commands

| Command            | What it does |
|--------------------|--------------|
| `edit()`           | Toggle editor mode on/off (badges + panel) |
| `edit.list()`      | Console table of every region: badge, slug, visible, edited |
| `edit.export()`    | Download `index.html` with all applied edits spliced in |
| `edit.before()`    | View the page as published (edits temporarily hidden) |
| `edit.after()`     | View the page with your applied edits again |
| `edit.revertAll()` | Discard every applied edit (asks for confirmation) |
| `edit.clear()`     | Wipe the quicksave slot |
| `edit.help()`      | Print this command list in the console |

## The modal

- **Apply**: pushes the textarea to the live page. This is the only thing that
  changes what you see. A tag-balance check runs first; if tags look unbalanced
  you get a confirm prompt instead of a silent broken page.
- **Revert**: restores this one region to its published content.
- **Cancel**: closes without applying, no questions asked (Esc does the same).
- **(X)** (top-right): also closes, but if the textarea holds changes you never
  Applied it asks "close and discard?" first. It's the safe-close affordance;
  Cancel/Esc are the quick-discard ones.
- **Quicksave**: saves the textarea to ONE universal slot in localStorage
  (a new quicksave overwrites the old one). It is a panic backup for
  "this is a lot of text, better save a copy", not a draft system.
- **Restore**: pastes the quicksave slot back into the current textarea, telling
  you which region it came from and how old it is. Nothing is applied until you
  press Apply. Restore works inside any region's modal.

Toolbar buttons wrap the selected text (or insert an empty pair at the cursor):
`<strong>`, `<em>`, link (`<a class="textlink">`, prompts for URL), `<br />`,
`<sup>`, `<sub>`, and the four size classes below.

## Text-size utility classes

Defined in the stylesheet (search "text-size utilities"). Em-based, relative to
the surrounding text; derived from sizes the page already uses:

- `.text-xs` (.76em, chip size) - `.text-sm` (.85em, meta/eyebrow)
- `.text-lg` (1.15em) - `.text-xl` (1.4em)

## Editing lifecycle and safety

- Applied edits live **in memory only**. Refreshing or closing the tab loses
  anything not exported; a browser close/refresh warning arms itself whenever you
  have applied-but-unexported edits. The only thing that persists is the one
  manual quicksave slot.
- Export fetches the pristine source over HTTP and splices ONLY the edited
  innerHTMLs back between their markers. Everything outside an edited region is
  byte-identical to the source, so git diffs stay clean.
- Inside an edited region the browser normalizes the HTML (for example
  `&middot;` becomes the literal character). Harmless, but it is why diffs of an
  edited region may show entity changes beyond your edit.

## How regions are marked (authoring)

Every editable region is fenced by a comment pair wrapping EXACTLY ONE element:

    <!--[edit:hero-h1]-->
    <h1>I help ambitious teams <span class="hl">ship the impossible</span>.</h1>
    <!--[/edit:hero-h1]-->

Rules when adding or moving markers by hand:

- One element per pair, slug unique, close marker must name the same slug.
- The editor edits that element's **innerHTML**; the element's own tag and
  attributes are never touched by export.
- Do NOT wrap an ALREADY-empty `.stats` / `.highlights` element by hand: the page
  JS culls empty unwrapped ones from the DOM at load. (Marker-wrapped ones are
  safe: the cull empties them instead of removing them, so a region you blank out
  through the editor survives export and reload and stays editable.)
- Deep-dive `<template class="deepdive">` elements are wrapped whole. They render
  nothing, so they get no on-page badge; open them from the panel list (marked
  "hidden"). Applied edits show the next time the drawer is opened.
- Badge IDs (A01...) are assigned at runtime in document order; slugs are the
  stable names.
- If a marker is malformed the editor logs a console warning and skips that
  region; everything else keeps working.

Currently swept (91 regions = 82 text + 9 galleries): header brand + nav links,
hero (eyebrow, h1, sub, note, CTAs), work intro, all 7 project blocks (title,
meta, lead, desc, stats/highlights when non-empty, spec rows, learn-more
button, deep-dive template, gallery), about (all paragraphs + link), contact
(heading, email, buttons, endbar), plus the 2 deep-dive galleries.

## Images: drag & drop gallery editing

Every carousel (the 7 project galleries and the 2 deep-dive galleries) is an
image region. The workflow:

1. Copy your final images into `img/work/` on disk (JPG, ~1600px long edge).
2. On the served page, enter `edit()` mode.
3. **Drag & drop a file onto a carousel: it replaces the photo you're looking
   at.** Navigate the carousel first to pick which photo to replace. Dropping
   several files at once replaces the visible one and appends the rest.
4. The editor previews the dropped file instantly (from the file data) and
   writes `img/work/<filename>` into the export. The filename must match what
   you copied to disk; the editor HEAD-checks the path and warns in the modal,
   the console, and at export if the file isn't on the server.
5. The **image modal** pops up on drop (and any time via the IMG## chip or the
   panel row): caption in the big box, alt text below, the src path shown
   underneath. Apply / Revert / Cancel / Quicksave / Restore / X work like the
   text modal, plus **Delete** removes the image (with confirm).
6. The **(+) chip** on each carousel adds an empty slot showing a dashed
   "Drop image here" tile. Unfilled slots are never exported.
7. `edit.export()` writes clean `<img>` lines between that gallery's markers.
   Everything else in the file stays byte-identical.

Seeds (`img/seed/` paths) are all-or-nothing placeholder filler: a gallery
shows them only while it has no real images, they carry no IMG## badge and
can't be captioned or deleted, and the first real drop replaces the whole seed
set. Deleting a gallery's last real image brings its seeds back (a project
gallery also falls back to seeds in the export; an empty deep-dive gallery
exports empty and the drawer simply omits it - a text-only deep dive is fine).

Deep-dive galleries live inside each project's `<template class="deepdive">`
(nested `[edit:fr3-dd-gallery]` markers inside the `fr3-deepdive` region -
the one place markers nest). Edit them with the drawer open ("Learn more");
drops and chips work on the drawer's carousel and are written back to the
template. Editing the deepdive TEXT region and its gallery at the same time is
supported: text splices first, then the gallery splice corrects the image list.
Two rules that follow from that: once a dd gallery is image-edited, its model
wins - `<img>` lines hand-typed into the deepdive TEXT box get overwritten by
the gallery splice at export - and never delete the nested `[edit:...-dd-gallery]`
markers inside the text box (export would abort with a console error naming
the slug).

IMG## badges are assigned in document order per session; slugs like
`fr3-gallery` are the stable names. The gallery chip label follows whichever
photo is visible (IMG##, SEED, or DROP for an empty slot).

## V2 plan: attribute-based text (not yet built)

Body copy and gallery images are covered. Other attribute-borne text is not
editable yet: the page `<title>`, meta/OG descriptions, `aria-label`s, and
`alt`/captions on non-gallery images (the portraits). The planned mechanism:

1. New marker placed just before the element, naming the attribute(s):
   `<!--[edit-attr:og-desc meta[property="og:description"] content]-->`
   (slug, a selector for the next element, and the attribute name).
2. Runtime: region value = `el.getAttribute(attr)`; the modal edits it as plain
   text (no toolbar); Apply sets the attribute.
3. Export: within the span between the attr marker and the end of the next
   element's opening tag, find `attr="..."` and replace the quoted value
   (attribute values must not contain `"` or `>`).
4. Head elements (`<title>`, `<meta>`) need the scanner to also walk
   `document.head`, and title editing sets `document.title`.

## Troubleshooting

- `edit is not defined`: the script tag at the bottom of `index.html` was lost or
  the page has a JS error earlier; check the console.
- Export does nothing / fails: you are on `file://` or offline. Serve over HTTP
  (`py -3 -m http.server` in the repo works) or edit on the live site.
- Badges misplaced after images load or a big layout change: they reposition on
  resize and after edits; toggling `edit()` off/on also rebuilds them.
- A region will not apply: the tag-balance prompt tells you which tag is
  unbalanced; fix the HTML in the textarea.
